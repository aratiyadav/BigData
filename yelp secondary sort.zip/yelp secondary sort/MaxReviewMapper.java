

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.json.JSONException;
import org.json.JSONObject;

public class MaxReviewMapper 
	extends Mapper<LongWritable, Text, KeyPair, Text> {
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
   
	  try{
		  JSONObject jsn = new JSONObject(value.toString());
		  String user_id=(String)jsn.get("user_id");
		  int stars = (Integer)jsn.get("stars");
		  String business_id=(String)jsn.get("business_id");
		  
		  context.write(new KeyPair(business_id, stars), new Text(user_id+"\t"+stars));
	  }
	  catch(JSONException e)
	  {
		  
	  }
}
}
