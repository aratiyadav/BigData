import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.*;


public class KeyPair implements WritableComparable<KeyPair>{
 
	//the key pair holds the businessID and stars
	private Text businessID;
	private IntWritable stars;
	
	//The defaule constructor
	public KeyPair()
	{
		businessID = new Text();
		stars= new IntWritable();
	}
	
	//constructor, initializing the businessID and stars
	public KeyPair(String last, int year)
	{
		businessID = new Text(last);
		stars= new IntWritable(year);
	}
	
	public void readFields(DataInput in) throws IOException {
		// TODO Auto-generated method stub
		businessID.readFields(in);
		stars.readFields(in);
	}

	
	public void write(DataOutput out) throws IOException {
		// TODO Auto-generated method stub
		businessID.write(out);
		stars.write(out);
	}


	public int compareTo(KeyPair otherPair) {
		// TODO Auto-generated method stub
		int c= businessID.compareTo(otherPair.businessID);
		if (c!=0)
			return c;
		else
			return stars.compareTo(otherPair.stars);
	}
	
	//the Getter and setter methods
	public Text getbusinessID() {
		return businessID;
	}

	public void setbusinessID(Text businessID) {
		this.businessID = businessID;
	}

	public IntWritable getstars() {
		return stars;
	}

	public void setstars(IntWritable stars) {
		this.stars = stars;
	}

	

}
