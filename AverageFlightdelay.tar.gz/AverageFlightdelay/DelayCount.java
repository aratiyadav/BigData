


import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.*;
public class DelayCount implements Writable{

private IntWritable partialSum;
private IntWritable partialCount;

//Default constructor
public DelayCount()
{
	partialSum = new IntWritable(0);
	partialCount=new IntWritable(0);
}

//Constructor, initializing the partial sum and partial count
public DelayCount(int sum, int count)
{
	this.partialSum= new IntWritable(sum);
	this.partialCount = new IntWritable(count);
}

//Accessors and Mutators
public int getPartialSum()
{
	return this.partialSum.get();
}

public int getPartialCount()
{
	return this.partialCount.get();
}

public void setPartialSum(int sum)
{
	this.partialSum=new IntWritable(sum);
}

public void setPartialCount(int count)
{
	this.partialCount= new IntWritable(count);
}


public void readFields(DataInput in) throws IOException {
	partialSum.readFields(in);
	partialCount.readFields(in);
	
}
public void write(DataOutput out) throws IOException {
	// TODO Auto-generated method stub
	partialSum.write(out);
	partialCount.write(out);
}
}
