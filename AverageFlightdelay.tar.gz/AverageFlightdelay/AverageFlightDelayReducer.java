import java.io.IOException;

import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class AverageFlightDelayReducer extends Reducer<Text, DelayCount, Text, IntWritable> {
  public void reduce(Text key, Iterable<DelayCount> values, Context context)
      throws IOException, InterruptedException {
    int sum = 0;
    int count=0;
    //Summing up the counts for each word
    for (DelayCount value : values) {
      sum += value.getPartialSum();
      count +=value.getPartialCount();
    }
    context.write(key, new IntWritable(sum/count));
  }
}
