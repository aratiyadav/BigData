import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class AverageFlightDelayMapper extends
    Mapper<LongWritable, Text, Text, DelayCount> {
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
  
   String[]columns= value.toString().split(",");
   String uniqueCarrier= columns[8];
   try
   {
	   //int deptDelay =Integer.parseInt(columns[15]);
     context.write(new Text(uniqueCarrier), new DelayCount(Integer.parseInt(columns[15]), 1));
   }
   catch (NumberFormatException e)
   {
   }
     
	  }
   }
  

